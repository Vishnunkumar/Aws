class TuningObjectives:
    def __init__(self, objectiveType, metricName):
        self.Type = objectiveType
        self.MetricName = metricName