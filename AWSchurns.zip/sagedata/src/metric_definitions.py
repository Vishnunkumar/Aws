class MetricDefinitions:
    def __init__(self, name, regex):
        self.Name = name
        self.Regex = regex


