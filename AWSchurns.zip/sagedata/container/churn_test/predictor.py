# This is the file that implements a flask server to do inferences. It's the file that you will modify to
# implement the scoring for your own algorithm.

from __future__ import print_function
from __future__ import division

import os
import json
import pickle
import StringIO
import sys
import signal
import traceback

import flask

import pandas as pd
import numpy as np
from sklearn import preprocessing
from sklearn.preprocessing import OneHotEncoder

prefix = '/opt/ml/'
model_path = os.path.join(prefix, 'model')
output_path = os.path.join(prefix, 'output')

# A singleton for holding the model. This simply loads the model and holds it.
# It has a predict function that does a prediction based on the model and the input data.

class ScoringService(object):
    model = None                # Where we keep the model when it's loaded

    @classmethod
    def get_model(cls):
        """Get the model object for this instance, loading it if it's not already loaded."""
        if cls.model == None:
            with open(os.path.join(model_path, 'Random-forest-model.pkl'), 'r') as inp:
                cls.model = pickle.load(inp)
        return cls.model

    @classmethod
    def predict(cls, input):
        """For the input, do the predictions and return them.

        Args:
            input (a pandas dataframe): The data on which to do the predictions. There will be
                one prediction per row in the dataframe"""
        clf = cls.get_model()
        return clf.predict(input)

# The flask app for serving predictions
app = flask.Flask(__name__)

@app.route('/ping', methods=['GET'])
def ping():
    """Determine if the container is working and healthy. In this sample container, we declare
    it healthy if we can load the model successfully."""
    health = ScoringService.get_model() is not None  # You can insert a health check here

    status = 200 if health else 404
    return flask.Response(response='\n', status=status, mimetype='application/json')

@app.route('/invocations', methods=['POST'])
def transformation():
    """Do an inference on a single batch of data. In this sample server, we take data as CSV, convert
    it to a pandas data frame for internal use and then convert the predictions back to CSV (which really
    just means one prediction per line, since there's a single column.
    """
    data = None

    # Convert from CSV to pandas
    if flask.request.content_type == 'text/csv':
        data = flask.request.data.decode('utf-8')
        s = StringIO.StringIO(data)
        data = pd.read_csv(s)
	
	# labels are in the first column
        label_encoder = preprocessing.LabelEncoder()

	data['state'] = label_encoder.fit_transform(data['state'])
	data['international plan'] = label_encoder.fit_transform(data['international plan'])
	data['voice mail plan'] = label_encoder.fit_transform(data['voice mail plan'])
	data['churn'] = label_encoder.fit_transform(data['churn'])

	# one hot encoding of catagorical variables

	enc = OneHotEncoder(categories = 'auto')

	catagories = ['state', 'area code']
	catagorical_data = data.loc[:,catagories]

	enc.fit(catagorical_data)
	one_hot = pd.DataFrame(enc.transform(catagorical_data).toarray())

	# combining it with the data

	data_f = pd.concat([data, one_hot], axis = 1)
	data_f.drop(["phone number","state","area code","churn"], axis = 1, inplace = True)

	# imputing missing columns
	old_columns = [u'account length',u'international plan', u'voice mail plan',u'number vmail messages', u'total day minutes', u'total day calls', u'total day charge',u'total eve minutes', u'total eve calls',u'total eve charge',u'total night minutes',u'total night calls', u'total night charge', u'total intl minutes', u'total intl calls', u'total intl charge', u'customer service calls',0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47,48,49,50,51,52,53]                       
	
	missing_cols = set(old_columns) - set(data_f.columns)
	for c in missing_cols:
	    data_f[c] = 0	
	
	data_f = data_f[old_columns]
	train_X = data_f.values.astype(np.float)
	
    else:
        return flask.Response(response='This predictor only supports CSV data', status=415, mimetype='text/plain')

    print('Invoked with {} records'.format(data.shape[0]))

    # Do the prediction
    predictions = ScoringService.predict(train_X)

    # Convert from numpy back to CSV
    out = StringIO.StringIO()
    pd.DataFrame({'results':predictions}).to_csv(out, header=False, index=False)
    
    #result = datas 
    result = out.getvalue()
    
    return flask.Response(response=result, status=200, mimetype='text/csv')
